import React, { Component } from "react";

class AddProject extends Component {
  render() {
    return (
      <div>
        <h1>Add Project Form</h1>
      </div>
    );
  }
}

export default AddProject;
